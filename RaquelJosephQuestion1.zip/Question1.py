from Matrices import Matrices

d = Matrices([[1, 2, 3], [4, 5, 6], [7, 8, 9]], [
             [1, 2, 3], [4, 5, 6], [7, 8, 9]], 'multiply')  # creates variable of function

print(d)
